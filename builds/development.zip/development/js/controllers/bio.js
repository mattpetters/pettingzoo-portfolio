myApp.controller('BioController', 
	function($scope, $location){


}); //BioController